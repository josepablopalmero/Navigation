# map1

Coordinates in [map1.csv](map1.csv) coordinates, file indices starting at 1,1:
- Origin: Line 3, Column 3. At resolution 1 pixel/meter = 1 meter/pixel: X = 2.5 m, Y = 2.5 m
- Destiny: Line 8, Column 3. At resolution 1 pixel/meter = 1 meter/pixel: X = 7.5 m, Y = 2.5 m

![map1.png](map1.png)
